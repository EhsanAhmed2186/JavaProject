public class Member {
    private String name,memberId;
    public Member(String a,String b){
        name=a;
        memberId=b;
    }
    public void nameSetter(String name){
        this.name=name;
    }
    public void idSetter(String memberId){
        this.memberId=memberId;
    }
    public String nameGetter(){
        return name;
    }
    public String idGetter(){
        return memberId;
    }
    @Override
    public String toString(){
        return "name:"+name+"memberid:"+memberId;
    }
}