import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Library {
    private ArrayList<Item> items;
    private ArrayList<Member> members;
    private ArrayList<CheckOutRecord> chekOutRecords;
    private Member loggedInMember;

    public Library() {
        this.items = new ArrayList<>();
        this.members = new ArrayList<>();
        this.chekOutRecords = new ArrayList<>();
        this.loggedInMember = null;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public String addBook(String itemId, String title, String category, ArrayList<String> authors, LocalDateTime publishDate, String publisherName) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String publishDateStr = publishDate.format(fmt);
        Book b = new Book(title, category, authors, publishDateStr, false, publisherName, 0, "");
        addItem(b);
        return b.getItemId();
    }

    public String addPublication( String title, String category, ArrayList<String> authors, LocalDateTime publishDate, String publisherName) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String publishDateStr = publishDate.format(fmt);
        Publication p = new Publication(title, category, authors, publishDateStr, false, publisherName);
        addItem(p);
        return p.getItemId();
    }

    public Item findItem(String itemId) throws InvalidItemException {
        for (Item it : items) {
            if (it.getItemId().equals(itemId)) {
                return it;
            }
        }
        throw new InvalidItemException(itemId);
    }

    public CheckOutRecord findCheckOutRecord(String itemId) {
        for (CheckOutRecord r : chekOutRecords) {
            if (r.getItemId().equals(itemId) && r.getCheckInTime() == null) {
                return r;
            }
        }
        return null;
    }

    public CheckOutRecord findCheckOutRecord(String itemId, String memberId) {
        for (CheckOutRecord r : chekOutRecords) {
            if (r.getItemId().equals(itemId) && r.getMemberId().equals(memberId) && r.getCheckInTime() == null) {
                return r;
            }
        }
        return null;
    }

    public ArrayList<CheckOutRecord> findCheckOutRecords(String id, boolean isMember) {
        ArrayList<CheckOutRecord> res = new ArrayList<>();
        if (isMember) {
            for (CheckOutRecord r : chekOutRecords) {
                if (r.getMemberId().equals(id)) {
                    res.add(r);
                }
            }
        } else {
            for (CheckOutRecord r : chekOutRecords) {
                if (r.getItemId().equals(id)) {
                    res.add(r);
                }
            }
        }
        return res.isEmpty() ? null : res;
    }

    public void checkOut(String itemId, String memberId) throws InvalidItemException, CheckedOutException {
        Item it = findItem(itemId);
        Member m = findMember(memberId);
        if (m == null) {
            throw new CheckedOutException("Invalid member id or Item id");
        }
        if (it.getIsCheckedOut()) {
            throw new CheckedOutException(itemId, it.getTitle());
        }
        it.setIsCheckedOut(true);
        CheckOutRecord rec = new CheckOutRecord(memberId, itemId);
        chekOutRecords.add(rec);
    }

    public void checkIn(String itemId) throws InvalidItemException, CheckedOutException {
        Item it = findItem(itemId);
        if (!it.getIsCheckedOut()) {
            throw new CheckedOutException("Invalid Check-in as Item is not checked out");
        }
        CheckOutRecord rec = findCheckOutRecord(itemId);
        if (rec == null) {
            throw new CheckedOutException("Invalid Check-in as no active checkout record found");
        }
        it.setIsCheckedOut(false);
        rec.returnItem();
    }

    public void extendCheckOut(String itemId, String memberId) throws InvalidItemException, CheckedOutException {
        Item it = findItem(itemId);
        Member m = findMember(memberId);
        if (m == null) {
            throw new CheckedOutException("Invalid member id or Item id");
        }
        if (!it.getIsCheckedOut()) {
            throw new CheckedOutException("Cannot extend the checkout as Item is not checked out");
        }
        CheckOutRecord rec = findCheckOutRecord(itemId, memberId);
        if (rec == null) {
            throw new CheckedOutException("Invalid member id or Item id");
        }
        LocalDateTime checkOutTime = rec.getCheckOutTime();
        LocalDateTime initialExpected = checkOutTime.plusWeeks(1);
        LocalDateTime currentExpected = rec.getExpectedCheckInTime();
        if (currentExpected.isBefore(initialExpected.plusSeconds(1)) || currentExpected.isEqual(initialExpected)) {
            rec.updateExpectedCheckinTime(currentExpected.plusWeeks(1));
        } else {
            throw new CheckedOutException("Already extended once. Cannot extend again");
        }
    }

    public ArrayList<Item> findItems(String itemTitle, String author) {
        ArrayList<Item> res = new ArrayList<>();
        for (Item it : items) {
            if (it.getTitle().toLowerCase().contains(itemTitle.toLowerCase()) && it.isAnAuthor(author)) {
                res.add(it);
            }
        }
        return res.isEmpty() ? null : res;
    }

    public ArrayList<Item> findItems(String itemType) {
        ArrayList<Item> res = new ArrayList<>();
        for (Item it : items) {
            String typeName = it.getClass().getSimpleName();
            if (typeName.equalsIgnoreCase(itemType)) {
                res.add(it);
            }
        }
        return res.isEmpty() ? null : res;
    }

    public void checkOut(String itemId) throws InvalidItemException, CheckedOutException {
        if (loggedInMember != null) {
            checkOut(itemId, loggedInMember.idGetter());
        }
    }

    public void extendCheckOut(String itemId) throws InvalidItemException, CheckedOutException {
        if (loggedInMember != null) {
            extendCheckOut(itemId, loggedInMember.idGetter());
        }
    }

    public ArrayList<CheckOutRecord> getCheckOutRecords(String itemId) throws InvalidItemException {
        findItem(itemId);
        return findCheckOutRecords(itemId, false);
    }

    public void addMember(String id, String name) {
        Member m = new Member(name, id);
        members.add(m);
    }

    private Member findMember(String memberId) {
        for (Member m : members) {
            if (m.idGetter().equals(memberId)) {
                return m;
            }
        }
        return null;
    }

    public void loginMember(String memberId) {
        Member m = findMember(memberId);
        this.loggedInMember = m;
    }

    public void logoutMember() {
        this.loggedInMember = null;
    }

    public ArrayList<Item> getAllItems() {
        return items;
    }

    public ArrayList<Member> getAllMembers() {
        return members;
    }

    public ArrayList<CheckOutRecord> getAllCheckOutRecords() {
        return chekOutRecords;
    }

    public Member getLoggedInMember() {
        return loggedInMember;
    }
}
