import java.util.ArrayList;

public class Book extends Item {
    private int numberOfPages;
    private String isbn;

    public Book(String title, String category, ArrayList<String> authors, String publishDate, boolean isCheckedOut, String publisherName, int numberOfPages, String isbn) {
        super(title, category, authors, publishDate, isCheckedOut, publisherName);
        this.numberOfPages = numberOfPages;
        this.isbn = isbn;
    }
    
    public int getNumberOfPages() { return numberOfPages; }
    public String getIsbn() { return isbn; }

    public void setNumberOfPages(int numberOfPages) { this.numberOfPages = numberOfPages; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
}
