import java.util.ArrayList;

public class Publication extends Item {
    public Publication( String title, String category, ArrayList<String> authors, String publishDate, boolean isCheckedOut, String publisherName) {
        super( title, category, authors, publishDate, isCheckedOut, publisherName);
    }
}
